/*
 * tft9325.h
 *
 *  Created on: 2020-10-30
 *      Author: Administrator
 */

#ifndef BSP_TFT9325_H_
#define BSP_TFT9325_H_

#include "DSP2833x_Device.h"
#include "DSP2833x_Examples.h"


#define TFTLCD_RST (*((unsigned int *)0x4100))
#define TFTLCD_COM (*((unsigned int *)0x4400))
#define TFTLCD_DAT (*((unsigned int *)0x4500))


#define RED                 0xf800              //��ɫ��RGB65��ʽ��
#define GREEN               0x07e0              //��ɫ
#define BLUE                0x001f              //��ɫ
#define YELLOW              0xffe0              //��ɫ
#define BLACK               0x0000              //��ɫ
#define WHITE               0xffff              //��ɫ
#define	GRAY                0x8410              //��ɫ

#define WINDOW_XADDR_START	0x0050 // Horizontal Start Address Set
#define WINDOW_XADDR_END	0x0051 // Horizontal End Address Set
#define WINDOW_YADDR_START	0x0052 // Vertical Start Address Set
#define WINDOW_YADDR_END	0x0053 // Vertical End Address Set
#define GRAM_XADDR		    0x0020 // GRAM Horizontal Address Set
#define GRAM_YADDR		    0x0021 // GRAM Vertical Address Set
#define GRAMWR 			    0x0022 // memory write

extern Uint16 ColorArray[7];
extern Uint16 *ExRamImage;

void ErasePicBuf(Uint16 Color);
void Init9325Gpio(void);
void Write_Cmd(unsigned char DH,unsigned char DL);
void Write_Data(unsigned char DH,unsigned char DL);
void Write_Cmd_Data (unsigned char x,Uint16 y);
void Write_Data_U16(Uint16 y);
void LCD_SetPos(Uint16 x0,Uint16 x1,Uint16 y0,Uint16 y1);

void Put_pixel(Uint16 x,Uint16 y,Uint16 color);
void Show_RGB (Uint16 x0,Uint16 x1,Uint16 y0,Uint16 y1,Uint16 Color);
void CLR_Screen(Uint16 bColor);
void Line(Uint16 X0,Uint16 Y0,Uint16 X1,Uint16 Y1,Uint16 color);
void Rectangle(Uint16 left,Uint16 top,Uint16 right,Uint16 bottom,Uint16 color);
void Bar(Uint16 left,Uint16 top,Uint16 right,Uint16 bottom,Uint16 color);
void ILI9325_Init(void);

void delayms(Uint16 count);
void delay(unsigned int);
void ldelay(unsigned int);

void LCD_PutChar(unsigned short x, unsigned short y, char c, Uint16 fColor, Uint16 bColor);
void Put16x16(unsigned short x, unsigned short  y, unsigned char g[2], Uint16 fColor,Uint16 bColor);
void LCD_PutString(unsigned short x, unsigned short y, unsigned char*s, Uint16 fColor, Uint16 bColor);

void Smenu(Uint16 bcolor);

#endif /* TFT9325_H_ */
