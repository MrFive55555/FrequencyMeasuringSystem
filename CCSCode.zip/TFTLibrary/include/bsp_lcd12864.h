/*
 * bsp_lcd12864.h
 *
 *  Created on: 2020-12-22
 *      Author: Administrator
 */

#ifndef BSP_LCD12864_H_
#define BSP_LCD12864_H_

#include "DSP2833x_Device.h"

#define LCD12864_COM (*((unsigned int *)0x4200))
#define LCD12864_DAT (*((unsigned int *)0x4300))
#define comm 	(0)
#define dat  	(1)

extern int counter;


void LCD12864_Init(void);
void LCD12864_Menu(void);
void LCD12864_DrawPic(const unsigned char*ptr);

/*�������
 *��-BCAA	��-D6E9		��-BBB6
 *��-C1D6	��-BAA3		ӭ-D3AD
 *��-B4F3	ѧ-D1A7		��-C4E3
 *ѧ-D1A7	Ժ-D4BA
 * */
extern Uint16 HZBM[11];



#endif /* BSP_LCD12864_H_ */
