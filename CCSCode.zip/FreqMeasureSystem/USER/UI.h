/*
 * UI.h
 *
 *  Created on: 2022��11��4��
 *      Author: MiniSforum
 */

#ifndef USER_UI_H_
#define USER_UI_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�"
void initStart(void);
void AllInit();
void UIFunctionSelect(Uint16 flag,Uint16 adjustUI);
void updateUIValueAdjust(Uint16 flag,Uint16 changeValue);
void UIFunctionEntrance();
void UIValueAdjust();
void UISignalMeasure();
unsigned char *UIIntToString(Uint32 num);
#endif /* USER_UI_H_ */
