/*
 * eCAP.h
 *
 *  Created on: 2022��11��5��
 *      Author: MiniSforum
 */

#ifndef USER_ECAP_H_
#define USER_ECAP_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
void eCAPInit();
interrupt void ecap1_isr(void);
void detectSignal(Uint32 *freq,Uint32 *compareA);
#endif /* USER_ECAP_H_ */
