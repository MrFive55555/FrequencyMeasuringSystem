/*
 * button.h
 *
 *  Created on: 2022��9��21��
 *      Author: User
 */

#ifndef USER_BUTTON_H_
#define USER_BUTTON_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
void buttonEXINT1Init();
Uint16 scanButton();
void Exint1_Init(void);
interrupt void xint1_isr(void);
#endif /* USER_BUTTON_H_ */
