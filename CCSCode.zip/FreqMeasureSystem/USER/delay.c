/*
 * delay.c
 *
 *  Created on: 2022��9��21��
 *      Author: User
 */
#include "delay.h"
void delayLoop(){
	Uint32      i;
	Uint32      j;
	for(i=0;i<10;i++)
	for (j = 0; j < 100000; j++) {}
}



