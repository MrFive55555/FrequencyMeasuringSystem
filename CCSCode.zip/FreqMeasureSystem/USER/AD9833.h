/*
 * AD9833.h
 *
 *  Created on: 2022��11��2��
 *      Author: HCC
 */

#ifndef AD9833_H_
#define AD9833_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
enum waveform{
	SIN = 0,TRI,REC
};
void AD9833Init(void);
void AD9833WriteData(Uint16 x);
void AD9833OutputWaveform(Uint16 form,float32 freq);
void AD9833_SDATA(Uint16 x);
void AD9833_SCLK(Uint16 x);
void AD9833_FSYNC(Uint16 x);
#endif /* AD9833_H_ */
