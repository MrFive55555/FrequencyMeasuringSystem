/*
 * led.c
 *
 *  Created on: 2022��9��21��
 *      Author: User
 */
#include "led.h"
#include "delay.h"
#define LED *((Uint16*)0x4600)
const Uint16 ledCode[9]={0x7F,0xBF,0xDF,0xEF,0xF7,0xFB,0xFD,0xFE,0xFF};
void ledInit(void){
	//�ر�д����
	EALLOW;
	InitSysCtrl();
	DINT;
	InitPieCtrl();
	IER = 0x0000;
	IFR = 0x0000;
	InitPieVectTable();
	InitXintf();
	LED = 0xff;
	//����д����
	EDIS;
}
void flowLed(void){
	int i;
	for(i = 0;i<8;i++){
		LED = ledCode[i];
		delayLoop();
	}
}

