#include "UI.h"
void main(){
    AllInit();
    while(1){
        UIFunctionEntrance();
    }
}




