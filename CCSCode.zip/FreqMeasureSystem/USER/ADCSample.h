/*
 * ADCSample.h
 *
 *  Created on: 2022��11��1��
 *      Author: HCC
 */

#ifndef ADCSAMPLE_H_
#define ADCSAMPLE_H_
#include "DSP2833x_Device.h"   // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h" // DSP2833x Examples Include File
void initADC(void);
void initPWM(void);
interrupt void adc_isr(void);
#endif /* ADCSAMPLE_H_ */
