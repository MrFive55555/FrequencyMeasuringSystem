/*
 * ePWM.h
 *
 *  Created on: 2022��11��3��
 *      Author: MiniSforum
 */

#ifndef USER_EPWM_H_
#define USER_EPWM_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
void ePWMInit(Uint32 freq,Uint32 compareA,Uint32 compareB);
void EPwm1A_SetCompare(float32 percent);
void EPwm1B_SetCompare(float32 percent);
void EPwm1_SetFreq(float32 f);
void UIDirection();
#endif /* USER_EPWM_H_ */


