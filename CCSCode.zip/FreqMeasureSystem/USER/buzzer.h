/*
 * buzzer.h
 *
 *  Created on: 2022��9��21��
 *      Author: User
 */

#ifndef USER_BUZZER_H_
#define USER_BUZZER_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
void buzzerInit();
#define buzzerOn (GpioDataRegs.GPBCLEAR.bit.GPIO60 = 1)
#define buzzerOff (GpioDataRegs.GPBSET.bit.GPIO60 = 1)

#endif /* USER_BUZZER_H_ */
