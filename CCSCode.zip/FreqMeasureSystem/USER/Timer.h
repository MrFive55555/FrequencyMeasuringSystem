/*
 * Timer.h
 *
 *  Created on: 2022��9��28��
 *      Author: User
 */

#ifndef USER_TIMER_H_
#define USER_TIMER_H_
#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�
void TimerInit();
interrupt void cpu_timer0_isr(void);
interrupt void cpu_timer1_isr(void);
#endif /* USER_TIMER_H_ */
